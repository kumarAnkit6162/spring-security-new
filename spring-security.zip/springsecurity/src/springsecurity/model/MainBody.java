package springsecurity.model;

import com.google.gson.annotations.Expose;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Represents the main body of Right Chart Panel JSON String
 */
public class MainBody {

  /**
   * Vars
   */
  @Expose
  private String id;
  @Expose
  private String LastName;
  @Expose
  private String FirstName;
  @Expose
  private String DOB;
  @Expose
  private String Zip;
  @Expose
  private String Gender;
  @Expose
  private List<Program> programs;
  @Expose
  private String quality_score;
  @Expose
  private Double mara_total_risk_score;
  @Expose
  private List<RecordId> record_ids;
  @Expose
  private String batchDate;
  @Expose
  private String measurementPeriodStartDate;
  @Expose
  private String measurementPeriodEndDate;

  /**
   * Empty Constructor
   */
  public MainBody() {
    this(null, null, null, null, null, null, null);
  }

  /**
   * Constructor
   *
   * @param id           String
   * @param lastName     String
   * @param firstName    String
   * @param dob          String
   * @param zip          String
   * @param gender       String
   * @param qualityScore String
   */
  public MainBody(
      String id,
      String lastName,
      String firstName,
      String dob,
      String zip,
      String gender,
      String qualityScore) {
    this.id = id;
    LastName = lastName;
    FirstName = firstName;
    DOB = dob;
    Zip = zip;
    Gender = gender;
    quality_score = qualityScore;
    mara_total_risk_score = null;
    programs = new ArrayList<>();
    record_ids = new ArrayList<>();
    batchDate = null;
    measurementPeriodStartDate = null;
    measurementPeriodEndDate = null;
  }

  /**
   * Adds a Program to programs
   *
   * @param program The Program to add
   */
  public void addProgram(Program program) {
    programs.add(program);
  }

  /**
   * Adds a RecordId to record_ids
   *
   * @param recordId The RecordId to add
   */
  public void addRecordId(RecordId recordId) {
    record_ids.add(recordId);
  }

  public String getBatchDate() {
    return batchDate;
  }

  public void setBatchDate(String batchDate) {
    this.batchDate = batchDate;
  }

  /**
   * @return the DOB
   */
  public String getDOB() {
    return DOB;
  }

  /**
   * @param dob the dob to set
   */
  public void setDOB(String dob) {
    if (null != dob) {
      DOB = dob.trim();
    }
  }

  /**
   * @return the FirstName
   */
  public String getFirstName() {
    return FirstName;
  }

  /**
   * @param firstName the FirstName to set
   */
  public void setFirstName(String firstName) {
    if (null != firstName) {
      FirstName = firstName.trim();
    }
  }

  /**
   * @return the Gender
   */
  public String getGender() {
    return Gender;
  }

  /**
   * @param gender the Gender to set
   */
  public void setGender(String gender) {
    if (null != gender) {
      Gender = gender.trim();
    }
  }

  /**
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * @param id the id to set
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * @return the LastName
   */
  public String getLastName() {
    return LastName;
  }

  /**
   * @param lastName the LastName to set
   */
  public void setLastName(String lastName) {
    if (null != lastName) {
      LastName = lastName.trim();
    }
  }

  /**
   * @return the mara_total_risk_score
   */
  public Double getMaraTotalRiskScore() {
    return mara_total_risk_score;
  }

  /**
   * @param maraTotalRiskScore the mara_total_risk_score to set
   */
  public void setMaraTotalRiskScore(Double maraTotalRiskScore) {
    mara_total_risk_score = maraTotalRiskScore;
  }

  public String getMeasurementPeriodEndDate() {
    return measurementPeriodEndDate;
  }

  public void setMeasurementPeriodEndDate(String measPeriodEndDate) {
    measurementPeriodEndDate = measPeriodEndDate;
  }

  public String getMeasurementPeriodStartDate() {
    return measurementPeriodStartDate;
  }

  public void setMeasurementPeriodStartDate(String measPeriodStartDate) {
    measurementPeriodStartDate = measPeriodStartDate;
  }

  /**
   * @return the programs
   */
  public List<Program> getPrograms() {
    return new LinkedList<>(programs);
  }

  /**
   * @param programs the programs to set
   */
  public void setPrograms(List<Program> programs) {
    this.programs = new LinkedList<>(programs);
  }

  /**
   * @return the quality_score
   */
  public String getQualityScore() {
    return quality_score;
  }

  /**
   * @param qualityScore the quality_score to set
   */
  public void setQualityScore(String qualityScore) {
    quality_score = qualityScore;
  }

  /**
   * @return the record_ids
   */
  public List<RecordId> getRecordIds() {
    return new ArrayList<>(record_ids);
  }

  /**
   * @param recordIds the record_ids to set
   */
  public void setRecordIds(List<RecordId> recordIds) {
    record_ids = new LinkedList<>(recordIds);
  }

  /**
   * @return the Zip
   */
  public String getZip() {
    return Zip;
  }

  /**
   * @param zip the Zip to set
   */
  public void setZip(String zip) {
    if (null != zip) {
      Zip = zip.trim();
    }
  }
}

