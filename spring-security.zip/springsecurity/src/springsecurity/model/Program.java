package springsecurity.model;


import com.google.gson.annotations.Expose;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a programs item
 */
public class Program {

  /**
   * Vars
   */
  @Expose
  private String id;
  @Expose
  private String name;
  @Expose
  private Boolean scorable;
  @Expose
  private Integer total_measure_count;
  @Expose
  private Integer met_measure_count;
  @Expose
  private List<Measure> measures;
  @Expose
  private List<SupportingFact> supporting_facts;

  /**
   * Empty Constructor
   */
  public Program() {
    this(null, null, null, null, null);
  }

  /**
   * Constructor
   *
   * @param id                String
   * @param name              String
   * @param scorable          Boolean
   * @param totalMeasureCount Integer
   * @param metMeasureCount   Integer
   */
  public Program(
      String id,
      String name,
      Boolean scorable,
      Integer totalMeasureCount,
      Integer metMeasureCount) {
    this.id = id;
    this.name = name;
    this.scorable = scorable;
    total_measure_count = totalMeasureCount;
    met_measure_count = metMeasureCount;
    measures = new ArrayList<>();
    supporting_facts = new ArrayList<>();
  }

  /**
   * Adds a Measure to measures
   *
   * @param measure The Measure to add
   */
  public void addMeasure(Measure measure) {
    measures.add(measure);
    total_measure_count = measures.size();
  }

  /**
   * Adds a SupportingFact to supporting_facts
   *
   * @param supportingFact The SupportingFact to add
   */
  public void addSupportingFact(SupportingFact supportingFact) {
    supporting_facts.add(supportingFact);
  }

  /**
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * @param id the id to set
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * @return the measures
   */
  public List<Measure> getMeasures() {
    return new ArrayList<>(measures);
  }

  /**
   * @param measures the measures to set
   */
  public void setMeasures(List<Measure> measures) {
    this.measures = new ArrayList<>(measures);
  }

  /**
   * @return the met_measure_count
   */
  public Integer getMetMeasureCount() {
    return met_measure_count;
  }

  /**
   * @param metMeasureCount the met_measure_count to set
   */
  public void setMetMeasureCount(Integer metMeasureCount) {
    met_measure_count = metMeasureCount;
  }

  /**
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * @param name the name to set
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * @return the scorable
   */
  public Boolean getScorable() {
    return scorable;
  }

  /**
   * @param scorable the scorable to set
   */
  public void setScorable(Boolean scorable) {
    this.scorable = scorable;
  }

  /**
   * @return the supporting_facts
   */
  public List<SupportingFact> getSupportingFacts() {
    return new ArrayList<>(supporting_facts);
  }

  /**
   * @param supportingFacts the supporting_facts to set
   */
  public void setSupportingFacts(List<SupportingFact> supportingFacts) {
    supporting_facts = new ArrayList<>(supportingFacts);
  }

  /**
   * @return the total_measure_count
   */
  public Integer getTotalMeasureCount() {
    return total_measure_count;
  }

  /**
   * @param totalMeasureCount the total_measure_count to set
   */
  public void setTotalMeasureCount(Integer totalMeasureCount) {
    total_measure_count = totalMeasureCount;
  }
}

