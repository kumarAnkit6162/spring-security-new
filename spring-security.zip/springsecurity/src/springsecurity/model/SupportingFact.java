package springsecurity.model;



import com.google.gson.annotations.Expose;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a supporting_facts item
 */
public class SupportingFact {

  /**
   * Vars
   */
  @Expose
  private String name;
  @Expose
  private String date;
  @Expose
  private String formatted_code;
  @Expose
  private String formatted_source;
  @Expose
  private List<Detail> details;

  /**
   * Empty Constructor
   */
  public SupportingFact() {
    this(null, null, null, null);
  }

  /**
   * Constructor
   *
   * @param name            String
   * @param date            String
   * @param formattedCode   String
   * @param formattedSource String
   */
  public SupportingFact(
      String name, String date, String formattedCode, String formattedSource) {
    this.name = name;
    this.date = date;
    details = new ArrayList<>();
    formatted_code = formattedCode;
    formatted_source = formattedSource;
  }

  /**
   * Adds a Detail to details
   *
   * @param detail The Detail to add
   */
  public void addDetail(Detail detail) {
    details.add(detail);
  }

  /**
   * @return the date
   */
  public String getDate() {
    return date;
  }

  /**
   * @param date the date to set
   */
  public void setDate(String date) {
    this.date = date.trim();
  }

  /**
   * @return the details
   */
  public List<Detail> getDetails() {
    return new ArrayList<>(details);
  }

  /**
   * @param details the details to set
   */
  public void setDetails(List<Detail> details) {
    this.details = new ArrayList<>(details);
  }

  /**
   * @return the formatted_code
   */
  public String getFormattedCode() {
    return formatted_code;
  }

  /**
   * @param formattedCode the formatted_code to set
   */
  public void setFormattedCode(String formattedCode) {
    formatted_code = formattedCode.trim();
  }

  /**
   * @return the formatted_source
   */
  public String getFormattedSource() {
    return formatted_source;
  }

  /**
   * @param formattedSource the formatted_source to set
   */
  public void setFormattedSource(String formattedSource) {
    formatted_source = formattedSource;
  }

  /**
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * @param name the name to set
   */
  public void setName(String name) {
    this.name = name.trim();
  }
}

