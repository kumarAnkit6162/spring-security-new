package springsecurity.model;



import com.google.gson.annotations.Expose;

/**
 * Represents a record_ids item
 */
public class RecordId {

  /**
   * Vars
   */
  @Expose
  private String data_partition_id;
  @Expose
  private String data_partition_person_id;

  /**
   * Empty Constructor
   */
  public RecordId() {
    this(null, null);
  }

  /**
   * Constructor
   *
   * @param dataPartitionId  String
   * @param dataPartPersonId String
   */
  public RecordId(String dataPartitionId, String dataPartPersonId) {
    data_partition_id = dataPartitionId;
    data_partition_person_id = dataPartPersonId;
  }

  /**
   * @return the data_partition_id
   */
  public String getDataPartitionId() {
    return data_partition_id;
  }

  /**
   * @param dataPartitionId the data_partition_id to set
   */
  public void setDataPartitionId(String dataPartitionId) {
    data_partition_id = dataPartitionId;
  }

  /**
   * @return the data_partition_person_id
   */
  public String getDataPartitionPersonId() {
    return data_partition_person_id;
  }

  /**
   * @param dataPartPersonId the data_partition_person_id to set
   */
  public void setDataPartitionPersonId(String dataPartPersonId) {
    data_partition_person_id = dataPartPersonId;
  }
}

