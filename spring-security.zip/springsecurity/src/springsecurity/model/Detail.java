package springsecurity.model;

public class Detail {

	  /**
	   * Empty Constructor
	   */
	  public Detail() {
	  }
	}
