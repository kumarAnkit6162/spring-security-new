package springsecurity.dao;

package analytics.rcp.dao;

import analytics.HedisDao;
import analytics.rcp.model.MainBody;
import analytics.rcp.model.Measure;
import analytics.rcp.model.Program;
import analytics.rcp.model.SupportingFact;
import com.ecw.dao.SqlTranslator;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import orderset.Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Dao extends HedisDao {

  private static final Logger LOGGER = LoggerFactory.getLogger(Dao.class);
  private static final int JOB_FINISHED = 6;

  /**
   * Determines which status a measure should have
   *
   * @param denominator The value for denominator
   * @param numerator   The value for numerator
   * @param exclusion   The value for exclusion
   * @return Returns a status string for the appropriate status
   */
  private String determineMeasureStatus(int denominator, int numerator, int exclusion) {
    if (exclusion == 1) {
      return "EXCLUDED";
    } else if (denominator == 1 && numerator == 1) {
      return "ACHIEVED";
    } else if (denominator == 1 && numerator == 0) {
      return "NOT_ACHIEVED";
    } else {
      return "MISSING_DATA";
    }
  }

  /**
   * Generates a list of SupportingFact for a given patientId, batchId, and measureId
   *
   * @param patientId The patient id
   * @param batchId   The batch id
   * @param measure   The Measure Object being referenced
   * @return Returns a List of SupportingFact
   */
  public List<SupportingFact> generateMeasureSupportingFacts(
      int patientId, int batchId, Measure measure) {
    List<SupportingFact> supportingFacts = new ArrayList<>();
    StringBuilder values = new StringBuilder();
    Date lastSatisfied = null;
    final String query =
        "SELECT DISTINCT q.valuesetId, q.valueset, md.compliantDate, md.compliantCode, md.compliantValue FROM cqm_measure_detail md LEFT JOIN cqm_query q ON q.valuesetId = md.valuesetId WHERE md.batchId = ? AND md.pid = ? AND md.measureId = ?";

    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query)) {
      int sqlIndex = 1;
      pstmt.setInt(sqlIndex++, batchId);
      pstmt.setInt(sqlIndex++, patientId);
      pstmt.setString(sqlIndex, measure.getFqn());
      try (ResultSet rs = pstmt.executeQuery()) {
        while (rs.next()) {
          SupportingFact supportingFact = new SupportingFact();
          supportingFact.setName(rs.getString("valueset"));
          supportingFact.setDate(rs.getString("compliantDate"));
          supportingFact.setFormattedCode(rs.getString("compliantCode"));
          supportingFacts.add(supportingFact);

          if (null != rs.getString("compliantValue")) {
            values.append(rs.getString("compliantValue").trim());
            values.append("|");
          }

          if (null == lastSatisfied || lastSatisfied.before(rs.getDate("compliantDate"))) {
            lastSatisfied = rs.getDate("compliantDate");
          }
        }
      }

      if (values.length() != 0) {
        values.deleteCharAt(values.lastIndexOf("|"));
        measure.setValueUnit(values.toString());
      } else {
        measure.setValueUnit(measure.getOutcome().toLowerCase());
      }

      if (null != lastSatisfied) {
        measure.setLastSatisfiedDate(lastSatisfied.toString());
      }
    } catch (Exception e) {
      LOGGER.error("HEDIS- ", e);
    }

    return supportingFacts;
  }

  /**
   * Generates a list of Measure Objects for a given patientId
   *
   * @param patientId The patient id to get data for
   * @return Returns a list of Measure Objects
   */
  public List<Measure> generateMeasures(int patientId, int batchId, String measureCategory,
      String query, Util osObj) {
    List<Measure> measures = new ArrayList<>();

    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query)) {
      int sqlIndex = 1;
      pstmt.setInt(sqlIndex++, batchId);
      pstmt.setInt(sqlIndex++, patientId);
      pstmt.setString(sqlIndex, measureCategory);
      try (ResultSet rs = pstmt.executeQuery()) {
        while (rs.next()) {
          Measure measure = new Measure();
          measure.setFqn(rs.getString("measure_id"));
          measure.setName(rs.getString("measure_description"));
          measure.setOutcome(
              determineMeasureStatus(rs.getInt("denominator"), rs.getInt("numerator"),
                  rs.getInt("exclusion")));
          measure.setOrdersetEncId(rs.getString("ordersetEncId"));
          if (null != measure.getOrdersetEncId() && !measure.getOrdersetEncId().isEmpty()) {
            String assmntIds =
                getAssessmentIds(Integer.parseInt(measure.getOrdersetEncId()), patientId, osObj);
            if (null != assmntIds && !assmntIds.isEmpty()) {
              measure.setAssmntIds(assmntIds);
            }
            measure.setOSSelectionType(rs.getString("osSelectionType"));
            if ("orderset".equals(measure.getOSSelectionType())) {
              measure.setItemName(rs.getString("description"));
            } else if ("lab".equals(measure.getOSSelectionType())
                || "di".equals(measure.getOSSelectionType())
                || "procedure".equals(measure.getOSSelectionType())) {
              measure.setItemName(rs.getString("itemName"));
            }
          }

          measure.setSelectedTreatmentAsmtId("0");
          measures.add(measure);
        }
      }
    } catch (Exception e) {
      LOGGER.error("HEDIS- ", e);
    }

    return measures;
  }

  /**
   * Generates a List of programs found in a given batch
   *
   * @param batchId int The batch identifier to get measure categories from
   * @return Returns a list of measure categories as programs
   */
  public List<Program> generatePrograms(int batchId) {
    List<Program> programs = new ArrayList<>();
    final String query =
        "SELECT DISTINCT ml.measure_category FROM PHM_PatientData pd INNER JOIN PHM_ReportData rd ON rd.id = pd.Reportdata_id INNER JOIN PHM_Measures_list ml ON ml.Measure_ID = rd.Measure_ID WHERE rd.batchid = ? ORDER BY ml.measure_category";

    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query)) {
      pstmt.setInt(1, batchId);
      try (ResultSet rs = pstmt.executeQuery()) {
        while (rs.next()) {
          Program program = new Program(
              "ecw.population-health.analytics.cqm." + rs.getString("measure_category"),
              rs.getString("measure_category"), Boolean.TRUE, 0, 0);
          programs.add(program);
        }
      }
    } catch (Exception e) {
      LOGGER.error("HEDIS- ", e);
    }
    return programs;
  }

  /**
   * Gets the assessmentIds associated with a given ordersetEncId for a patient
   *
   * @param encounterId The encounter identifier to get linked assessment ids for
   * @param patientId   The patient identifier to get linked assessment ids for
   * @return Returns a String of assessment id's
   * @throws Exception Throws Exception
   */
  private String getAssessmentIds(int encounterId, int patientId, Util osObj) throws Exception {
    return osObj.getLinkedAsmtIdsForOrderSet(null, encounterId, patientId);
  }

  /**
   * Gets the max completed batch id from cqm_job_status
   *
   * @return Returns the batch id
   */
  public int getMaxBatchId() {
    int maxBatchId = 0;
    final String query = "SELECT MAX(batchId) FROM cqm_job_status WHERE section = ?";

    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query)) {
      pstmt.setInt(1, JOB_FINISHED);
      try (ResultSet rs = pstmt.executeQuery()) {
        if (rs.next()) {
          maxBatchId = rs.getInt(1);
        }
      }
    } catch (Exception e) {
      LOGGER.error("HEDIS- ", e);
    }
    return maxBatchId;
  }

  public List<Measure> getMeasuresByCategory(String categoryName) {
    List<Measure> measures = new LinkedList<>();
    String query = "SELECT measure_id, measure_description FROM phm_measures_list WHERE measure_category = ? AND deleteFlag = ?";
    try (Connection con = getConnection();
    PreparedStatement pstmt = con.prepareStatement(query)) {
      int sqlIndex = 1;
      pstmt.setString(sqlIndex++, categoryName);
      pstmt.setInt(sqlIndex, 0);
      try (ResultSet rs = pstmt.executeQuery()) {
        while(rs.next()) {
          Measure measure = new Measure();
          measure.setFqn(rs.getString("measure_id"));
          measure.setName(rs.getString("measure_description"));
          measures.add(measure);
        }
      }
    } catch (Exception e) {
      LOGGER.error("An error occurred while getting measures for category: {}", categoryName, e);
    }
    return measures;
  }

  public String getPatientComplianceStatus(int batchId, int patientId, String measureId) {
    String status = "MISSING_DATA";
    String query = "SELECT CASE WHEN pd.e_denominator = 'EXMckhB5qTRqik0MZxSW9Q==' THEN 1 ELSE 0 END AS denominator, CASE WHEN pd.e_numerator = 'EXMckhB5qTRqik0MZxSW9Q==' THEN 1 ELSE 0 END AS numerator, CASE WHEN pd.e_denominator = '7poGHI70rNg+FHUPBKIZuA==' AND pd.e_numerator = '7poGHI70rNg+FHUPBKIZuA==' THEN 1 ELSE 0 END AS exclusion FROM phm_patientData pd INNER JOIN phm_reportData rd ON rd.id = pd.reportData_id INNER JOIN phm_measures_list ml ON ml.measure_id = rd.measure_id WHERE rd.batchId = ? AND pd.patient_id = ? AND ml.measure_id = ? AND pd.deleteFlag = ? AND rd.deleteFlag = ? AND ml.deleteFlag = ?";
    try (Connection con = getConnection();
    PreparedStatement pstmt = con.prepareStatement(query)) {
      int sqlIndex = 1;
      pstmt.setInt(sqlIndex++, batchId);
      pstmt.setInt(sqlIndex++, patientId);
      pstmt.setString(sqlIndex++, measureId);
      pstmt.setInt(sqlIndex++, 0);
      pstmt.setInt(sqlIndex++, 0);
      pstmt.setInt(sqlIndex, 0);
      try (ResultSet rs = pstmt.executeQuery()) {
        if (rs.next()) {
          status = determineMeasureStatus(rs.getInt("denominator"), rs.getInt("numerator"), rs.getInt("exclusion"));
        }
      }
    } catch (Exception e) {
      LOGGER.error("An error occurred while getting compliance data", e);
    }
    return status;
  }

  /**
   * Sets the batch information on the supplied MainBody Object
   *
   * @param mainBody The MainBody Object to set values in
   */
  public void setBatchInfo(MainBody mainBody, int batchId) {
    final String query = "SELECT extract_date, reporting_start_date, reporting_end_date from phm_schedule_detail WHERE id = ?;";
    SimpleDateFormat simpleFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);

    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query)) {
      pstmt.setInt(1, batchId);
      try (ResultSet rs = pstmt.executeQuery()) {
        if (rs.next()) {
          mainBody.setBatchDate(simpleFormat.format(rs.getDate("extract_date")));
          mainBody.setMeasurementPeriodStartDate(
              simpleFormat.format(rs.getDate("reporting_start_date")));
          mainBody
              .setMeasurementPeriodEndDate(simpleFormat.format(rs.getDate("reporting_end_date")));
        }
      }
    } catch (Exception e) {
      LOGGER.error("HEDIS- ", e);
    }
  }

  /**
   * Sets MainBody user information fields
   *
   * @param patientId The patient identifier to retrieve data for
   * @param mainBody  The MainBody to set values for
   */
  public void setUserInfo(int patientId, MainBody mainBody) {
    final String query = "SELECT ulname, ufname, ptDob, zipcode, sex FROM users WHERE uid = ?";
    SimpleDateFormat simpleFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);

    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query)) {
      pstmt.setInt(1, patientId);
      try (ResultSet rs = pstmt.executeQuery()) {
        if (rs.next()) {
          mainBody.setLastName(rs.getString("ulname"));
          mainBody.setFirstName(rs.getString("ufname"));
          mainBody.setDOB(simpleFormat.format(rs.getDate("ptDob")));
          mainBody.setZip(rs.getString("zipcode"));
          mainBody.setGender(rs.getString("sex"));
        }
      }
    } catch (Exception e) {
      LOGGER.error("HEDIS- ", e);
    }
  }

  public int addSuppressMeasure(HashMap<String, String> params) {
    int result = -1;
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    String query = "INSERT INTO cqm_rcp_suppress(pid, measureId, suppressUntil, suppressComment) SELECT ?, ?, ?, ? ";
    if (!(params.containsKey("patientId") && params.containsKey("measureId") && params.containsKey("suppressUntil") && params.containsKey("suppressComment"))) {
      return result;
    }
    try (Connection con = getConnection();
         PreparedStatement pstmt = con.prepareStatement(query)) {
      int sqlIndex = 1;
      pstmt.setInt(sqlIndex++, Integer.parseInt(params.get("patientId")));
      pstmt.setString(sqlIndex++, params.get("measureId"));
      pstmt.setString(sqlIndex++, params.get("suppressUntil"));
      pstmt.setString(sqlIndex, params.get("suppressComment"));
      pstmt.executeUpdate();
      result = 1;
    } catch (Exception e) {
      LOGGER.error("HEDIS- ", e);
    }
    return result;
  }

  public JsonArray getSuppressedMeasure(int patientId) {
    JsonArray jArr = new JsonArray();
    StringBuilder query = new StringBuilder();
    query.append("select distinct ml.Measure_Category, rcp.measureId from cqm_rcp_suppress rcp inner join phm_measures_list ml ON ml.Measure_Id = rcp.measureId and rcp.suppressUntil > ")
    .append(SqlTranslator.isDbMySql() ? "CURDATE()" : "getdate()")
    .append(" and rcp.pid = ?  ORDER BY ml.Measure_Category ");
    try (Connection con = getConnection();
         PreparedStatement pstmt = con.prepareStatement(query.toString())) {
      pstmt.setInt(1, patientId);
      try (ResultSet rs = pstmt.executeQuery()) {
        while (rs.next()) {
          JsonObject jObj = new JsonObject();
          jObj.addProperty("category", rs.getString("Measure_Category"));
          jObj.addProperty("measureId", rs.getString("measureId"));
          jArr.add(jObj);
        }
      }
    } catch (Exception e) {
      LOGGER.error("HEDIS- ", e);
    }
    return jArr;
  }

  public int deleteSuppressMeasure(HashMap<String, String> params) {
    int result = -1;
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    String query = "DELETE FROM cqm_rcp_suppress WHERE pid = ? AND measureId = ? ";
    if (!(params.containsKey("patientId") && params.containsKey("measureId"))) {
      return result;
    }
    try (Connection con = getConnection();
         PreparedStatement pstmt = con.prepareStatement(query)) {
      int sqlIndex = 1;
      pstmt.setInt(sqlIndex++, Integer.parseInt(params.get("patientId")));
      pstmt.setString(sqlIndex, params.get("measureId"));
      pstmt.executeUpdate();
      result = 1;
    } catch (Exception e) {
      LOGGER.error("HEDIS- ", e);
    }
    return result;
  }

}

