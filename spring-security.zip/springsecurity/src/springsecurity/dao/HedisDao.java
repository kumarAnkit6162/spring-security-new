package springsecurity.dao;

package analytics;

import catalog.Root;
import com.ecw.dao.SqlTranslator;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HedisDao {

  private static final Logger LOGGER = LoggerFactory.getLogger(HedisDao.class);
  protected String hedisItemKey = "pophealth_hedis";

  public boolean checkForHedis() {
    return checkForProgram("HEDIS");
  }

  public boolean checkForProgram(String programName) {
    String query = "SELECT 1 FROM cqm_programs WHERE programName = ?";

    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query)) {
      pstmt.setString(1, programName);
      try (ResultSet rs = pstmt.executeQuery()) {
        if (rs.next()) {
          return true;
        }
      }
    } catch (Exception e) {
      LOGGER.error("HedisDao- checkForHedis: ", e);
    }
    return false;
  }

  /**
   * Attempts to close a BufferedReader
   */
  public void close(BufferedReader bufferedReader) {
    if (bufferedReader != null) {
      try {
        bufferedReader.close();
      } catch (IOException e) {
        LOGGER.error("HedisDao- closeBufferedReader: ", e);
      }
    }
  }

  /**
   * Attempts to close a Connection
   */
  public void close(Connection con) {
    if (con != null) {
      try {
        con.close();
      } catch (SQLException e) {
        LOGGER.error("HedisDao- closeConnection: ", e);
      }
    }
  }

  /**
   * Attempts to close a OutputStream
   */
  public void close(OutputStream outputStream) {
    if (outputStream != null) {
      try {
        outputStream.close();
      } catch (IOException e) {
        LOGGER.error("HedisDao- closeOutputStream: ", e);
      }
    }
  }

  /**
   * Attempts to close a PreparedStatement
   */
  public void close(PreparedStatement pstmt) {
    if (pstmt != null) {
      try {
        pstmt.close();
      } catch (SQLException e) {
        LOGGER.error("HedisDao- closePreparedStatement: ", e);
      }
    }
  }

  /**
   * Attempts to close a ResultSet
   */
  public void close(ResultSet rs) {
    if (rs != null) {
      try {
        rs.close();
      } catch (SQLException e) {
        LOGGER.error("HedisDao- closeResultSet: ", e);
      }
    }
  }

  /**
   * Attempts to close a Statement
   */
  public void close(Statement stmt) {
    if (stmt != null) {
      try {
        stmt.close();
      } catch (SQLException e) {
        LOGGER.error("HedisDao- closeStatement: ", e);
      }
    }
  }

  public void deleteFailedCriteria(int mode, int batchSize, String message,
      Set<Integer> activePopulation) throws SQLException {
    StringBuilder query = new StringBuilder();
    query.append("UPDATE cqm_resultSet SET deleteFlag = 1, compliantCode = ?");
    if (HedisConstants.EXCLUDED_FUTURE_BIRTHDAY_GENERATEACTIVEPATIENTQUERY == mode) {
      query.append(", dob = NULL");
    }
    query.append(" WHERE valuesetId = '1' AND pid = ?");

    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query.toString())) {
      int count = 0;
      for (Integer pid : activePopulation) {
        count++;
        int sqlIndex = 1;
        pstmt.setString(sqlIndex++, message);
        pstmt.setInt(sqlIndex, pid);
        pstmt.addBatch();

        if (count == batchSize) {
          pstmt.executeBatch();
          count = 0;
        }
      }
      pstmt.executeBatch();
    } catch (Exception e) {
      throw new SQLException(
          "An error occurred while deleting failed criteria patients from the resultset",
          e
      );
    }
  }

  public int getActiveConfigId(String tableName) {
    String query = String.format("SELECT id FROM %s WHERE active = ?", tableName);
    int result = -1;
    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query)) {
      pstmt.setInt(1, 1);
      try (ResultSet rs = pstmt.executeQuery()) {
        while (rs.next()) {
          result = rs.getInt("id");
        }
      }
    } catch (Exception e) {
      LOGGER.error("An error occurred while getting the active config id- ", e);
    }
    return result;
  }

  /**
   * Gets a list of Administrator identifiers
   *
   * @return Returns an Integer List of identifiers
   */
  public List<Integer> getAdminIds() {
    List<Integer> adminIds = new LinkedList<>();
    String query = "SELECT uid FROM users u INNER JOIN itemkeys i ON i.itemId = u.uid AND i.name = 'Administrator'";
    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query);
        ResultSet rs = pstmt.executeQuery()) {
      while (rs.next()) {
        adminIds.add(rs.getInt(1));
      }
    } catch (Exception e) {
      LOGGER.error("HEDIS- getAdmins: ", e);
    }
    return adminIds;
  }

  /**
   * Gets a list of configured providers
   *
   * @return Returns a List of configured provider id's
   */
  protected List<Integer> getConfiguredProviders() {
    String query = "SELECT provider_selected FROM cqm_client_config WHERE active = 1;";
    Optional<String> configuredProviders = Optional.empty();
    List<Integer> providers = new LinkedList<>();

    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query);
        ResultSet rs = pstmt.executeQuery()) {
      while (rs.next()) {
        configuredProviders = Optional.ofNullable(rs.getString("provider_selected"));
      }
    } catch (Exception e) {
      LOGGER.error("HedisDao- getConfiguredProviders: ", e);
    }

    if (configuredProviders.isPresent() && !configuredProviders.get().isEmpty()) {
      for (String provider : configuredProviders.get().split(",")) {
        providers.add(Integer.valueOf(provider));
      }
    }

    return providers;
  }

  /**
   * Helper method for getConnection(Int retry)
   *
   * @return Returns the connection or null if unable to connect
   * @throws Exception if error encountered
   */
  public Connection getConnection() throws Exception {
    return getConnection(0);
  }

  /**
   * Generates a root db connection
   *
   * @return Connection object
   * @throws Exception if error encountered
   */
  public Connection getConnection(int retry) throws Exception {
    Connection con = null;
    Statement stmt = null;
    int seconds = HedisConstants.CONNECTION_RETRY_WAIT * retry;
    Thread.sleep(seconds);
    Root root;
    if (retry < HedisConstants.CONNECTION_RETRIES) {
      try {
        root = Root.createDbConnection(null);
        root.con.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);
        Root.setMySqlSessionTimeOut(root.con);
        if (SqlTranslator.isDbMySql()) {
          stmt = root.con.createStatement();
          //language=MySQL
          stmt.execute(
              "SET SESSION group_concat_max_len = 18446744073709551615"); //THIS IS TO BYPASS THE GROUP_CONCAT() LIMIT OF 1024bytes
        }
        con = root.con;
      } catch (SQLException e) {
        LOGGER.error("HedisDao- getConnection: ", e);
        con = getConnection(retry + 1);
      } finally {
        close(stmt);
      }
    }
    return con;
  }

  /**
   * Gets the HEDIS version from the itemkey
   *
   * @return Returns the String HEDIS version
   */
  public String getHedisVersion() {
    String version = "4.0.0";
    String supportRemarks = "";
    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement("SELECT supportRemarks FROM itemkeys WHERE name = ?")) {
      pstmt.setString(1, hedisItemKey);
      try (ResultSet rs = pstmt.executeQuery()) {
        while (rs.next()) {
          supportRemarks = rs.getString(1);
        }
        String pat = "[V]{1}[\\d+[.]?]+";
        Pattern p = Pattern.compile(pat);
        Matcher m = p.matcher(supportRemarks);
        if (m.find()) {
          version = m.group(0);
        }
      }
    } catch (Exception e) {
      LOGGER.error("CqmDashboardDao - getHedisVersion: ", e);
    }
    return version;
  }

  /**
   * Gets a List of logged provider id's for the current year
   *
   * @param currentYear int representation of the current year
   * @return Returns a List of provider id's
   */
  protected List<Integer> getLoggedProviders(int currentYear) {
    String query = "SELECT providerId FROM cqm_hedisProviderTracking WHERE createdYear = ?;";
    List<Integer> providers = new LinkedList<>();

    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query)) {
      pstmt.setInt(1, currentYear);
      try (ResultSet rs = pstmt.executeQuery()) {
        while (rs.next()) {
          providers.add(rs.getInt("providerId"));
        }
      }
    } catch (Exception e) {
      LOGGER.error("HedisDao- getLoggedProviders: ", e);
    }

    return providers;
  }

  /**
   * Gets a List of providerIds that have been selected for measure calculation
   *
   * @return Returns a List<String> of provider ids
   */
  public List<String> getProviders() {
    List<String> result = new LinkedList<>();
    String query = "SELECT providerId from cqm_providers WHERE selected = ?";

    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query)) {
      pstmt.setInt(1, 1);
      try (ResultSet rs = pstmt.executeQuery()) {
        while (rs.next()) {
          result.add(rs.getString(1));
        }
      }
    } catch (Exception e) {
      LOGGER.error("HEDIS- getProviders: ", e);
    }
    return result;
  }

  public boolean hasEntries(String tableName) {
    String query = String.format("SELECT COUNT(1) as count FROM %s", tableName);
    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query);
        ResultSet rs = pstmt.executeQuery()) {
      return rs.next() && rs.getInt("count") > 0;
    } catch (Exception e) {
      LOGGER.error("An error occurred while checking for entries", e);
    }
    return false;
  }

  public int insertMeasProvCalculatedData(int batchId, int totalProviders, int selectedProviders,
      int totalMeasures, String selectedMeasures) {
    int result = 0;
    String query = "INSERT INTO cqm_resultset_historical (valuesetId, comments, batchId, startTime, stopTime) VALUES (?, ?, ?, ?, ?)";

    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query)) {
      int sqlIndex = 1;
      pstmt.setString(sqlIndex++, "Total Provider Count");
      pstmt.setString(sqlIndex++, Integer.toString(totalProviders));
      pstmt.setInt(sqlIndex++, batchId);
      pstmt.setTimestamp(sqlIndex++, Timestamp.valueOf(LocalDateTime.now()));
      pstmt.setTimestamp(sqlIndex, Timestamp.valueOf(LocalDateTime.now()));
      pstmt.addBatch();

      sqlIndex = 1;
      pstmt.setString(sqlIndex++, "Selected Provider Count");
      pstmt.setString(sqlIndex, Integer.toString(selectedProviders));
      pstmt.addBatch();

      sqlIndex = 1;
      pstmt.setString(sqlIndex++, "Total Measure Count");
      pstmt.setString(sqlIndex, Integer.toString(totalMeasures));
      pstmt.addBatch();

      sqlIndex = 1;
      pstmt.setString(sqlIndex++, "Selected Measures");
      pstmt.setString(sqlIndex, selectedMeasures);
      pstmt.addBatch();

      for (int insert : pstmt.executeBatch()) {
        result += insert;
      }
    } catch (Exception e) {
      LOGGER.error("HedisDao- insertMeasProvCalculatedData:", e);
    }
    return result;
  }

  /**
   * Inserts list of new providers into the cqm_hedisProviderTracking table
   *
   * @param newProviders The List of provider id's to insert
   * @param currentDate  The current date to create entries with
   */
  protected void insertTrackingProviders(List<Integer> newProviders, LocalDate currentDate) {
    String query = "INSERT INTO cqm_hedisProviderTracking (providerId, createdYear, createdDate) VALUES (?, ?, ?);";

    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query)) {
      pstmt.setInt(HedisConstants.PROVIDER_TRACKING_CREATED_YEAR, currentDate.getYear());
      pstmt.setDate(HedisConstants.PROVIDER_TRACKING_CREATED_DATE, Date.valueOf(currentDate));
      for (Integer provider : newProviders) {
        pstmt.setInt(HedisConstants.PROVIDER_TRACKING_PROVIDER_ID, provider);
        pstmt.addBatch();
      }
      pstmt.executeBatch();
    } catch (Exception e) {
      LOGGER.error("HedisDao- insertProviders: ", e);
    }
  }

  /**
   * Runs a supplied query that has no parameters
   */
  public void runUpdateQuery(String query) throws SQLException {
    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query)) {
      pstmt.executeUpdate();
    } catch (Exception e) {
      throw new SQLException(e);
    }
  }

  public void updateDatetimeFieldForValuesetId(String valuesetId, LocalDateTime now, String query)
      throws SQLException {
    try (Connection con = getConnection();
        PreparedStatement pstmt = con.prepareStatement(query)) {
      int sqlIndex = 1;
      pstmt.setTimestamp(sqlIndex++, Timestamp.valueOf(now));
      pstmt.setString(sqlIndex, valuesetId);
      pstmt.executeUpdate();
    } catch (Exception e) {
      throw new SQLException(e);
    }
  }

  public int getCqmItemsValue(String itemName) {
    int result = 0;
    try (Connection con = getConnection();
         PreparedStatement ps = con.prepareStatement("SELECT value FROM cqm_items WHERE name = ? ")) {
      ps.setString(1, itemName);
      try (ResultSet rs = ps.executeQuery()) {
        if (rs.next()) {
          result = Integer.parseInt(rs.getString("value"));
        }
      }
    } catch (Exception e) {
      LOGGER.error("HedisDao - getCqmItemsValue: ", e);
    }
    return result;
  }

  public JsonObject getCountOfPhmPatientData(int reportDataId) {
    JsonObject jObj = new JsonObject();
    try (Connection con = getConnection();
         PreparedStatement ps = con.prepareStatement("SELECT COUNT(id) as ct, MIN(id) as min, MAX(id) as max FROM phm_patientdata WHERE reportdata_id = ? ")) {
      ps.setInt(1, reportDataId);
      try (ResultSet rs = ps.executeQuery()) {
        if (rs.next()) {
          jObj.addProperty("ct", rs.getInt("ct"));
          jObj.addProperty("min", rs.getInt("min"));
          jObj.addProperty("max", rs.getInt("max"));
        }
      }
    } catch (Exception e) {
      LOGGER.error("HedisDao - getCountOfPhmPatientData: ", e);
    }
    return jObj;
  }

  public int getBatchSize() {
    int result = 0;
    try (Connection con = getConnection(); PreparedStatement pstmt = con.prepareStatement("SELECT batchSize FROM cqm_client_config where active=?"); ) {
      pstmt.setInt(1, 1);
      try (ResultSet rs = pstmt.executeQuery()) {
        if (rs.next()) {
          result = rs.getInt("batchSize");
        }
      }
    } catch (Exception e) {
      LOGGER.error("HedisDao- getBatchSize: ", e);
    }
    return result;
  }

  public String getItemKeyValue(String itemName) {
    String query = "SELECT value FROM itemkeys WHERE name = ? ";
    String result = "";
    try (Connection con = getConnection(); PreparedStatement pstmt = con.prepareStatement(query)) {
      pstmt.setString(1, itemName);
      try (ResultSet rs = pstmt.executeQuery()) {
        if (rs.next()) {
          result = rs.getString("value");
        }
      }
    } catch (Exception e) {
      LOGGER.error("HedisDao- getItemKeyValue: ", e);
    }
      return result;
  }

}

