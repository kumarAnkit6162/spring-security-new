/**
 * 
 */
/**
 * @author ankit.kumarsingh
 *
 */
module springsecurity {
}